plain archive entry
